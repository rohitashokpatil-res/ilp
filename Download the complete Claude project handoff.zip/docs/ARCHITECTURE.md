# Architecture Notes

## Trust boundaries

Trusted: normalized source, validated clarification decisions, schemas, deterministic validators, fixed generation policies, reviewed theorem templates, Lean compiler.

Untrusted until validated: every LLM response, generated Lean code, requested names, dependency metadata, and compiler-diagnostic parsing.

## Semantic distinctions

- Requirement proposition is not an axiom.
- Permission is not occurrence.
- Prohibition is not automatically negated permission.
- Decision assignment is not interchangeable with an unrelated predicate.
- Distinct is not mutually exclusive.
- Mutually exclusive is not closed.
- Closed is not single-valued.
- Functional is not total.
- Role is not type.
- Relationship is not automatically a field.
- Failed conflict proof is not proof of consistency.

## ID families

```text
REQ-*     requirement
AMB-*     ambiguity
CLAR-*    clarification
REF-*     refinement
CTX-*     context record
CPT-*     canonical concept
IR-*      requirement IR
PREQ-*    preamble request local to an IR
RBIND-*   shared-symbol binding local to an IR
RCON-*    representation constraint local to an IR
PDECL-*   preamble declaration
SYM-*     preamble symbol
M5DECL-*  M5 local declaration
TEST-*    test instance
TBIND-*   test binding
VRES-*    verification result
```
