# Acceptance and Mutation Tests

## Acceptance A: shared transaction model

Ground a Transaction entity, amount field, closed TransactionDecision domain with approved and rejected, and a transaction decision accessor. Two requirements assign different values under overlapping numeric conditions.

Expected: PREQ merge uses canonical identity, RBIND resolves exact SYM IDs, M5 uses exact symbols, preamble and requirements compile.

## Acceptance B: unresolved decision semantics

Approve and reject occur without a grounded shared decision domain or exclusivity.

Expected: no closed decision type or incompatibility is invented. Verification remains blocked or inconclusive according to policy.

## Acceptance C: open domain

An open single-valued domain is grounded.

Expected: it is not encoded as a closed inductive type unless the policy explicitly defines a safe open-domain strategy.

## Acceptance D: relation not attribute

A belongs-to relation has `relation_not_attribute`.

Expected: generate/reuse a relation, not an owner field.

## Acceptance E: exact-one cardinality

Every account belongs to exactly one holder.

Expected: scoped functionality and totality metadata, visible existence and uniqueness in requirement logic, no finite-domain assumption.

## Acceptance F: vague temporal requirement

The requirement says processing occurs quickly without duration.

Expected: blocked semantics, no invented number or unit, no guessed complete requirement proposition.

## Mutation set

1. Reverse implication.
2. Change `<` to `<=`.
3. Remove negation.
4. Convert permission to occurrence.
5. Bind RBIND to the wrong PREQ.
6. Resolve a symbol by approximate name.
7. Duplicate declaration name.
8. Add undeclared dependency.
9. Create dependency cycle.
10. Add `axiom` to M5.
11. Add `theorem` or `by` to M-Preamble.
12. Add HTML entities to Lean.
13. Encode open domain as closed inductive.
14. Generate total accessor without totality.
15. Violate relation_not_attribute.
16. Violate role_not_type.
17. Remove coverage for one IR element.
18. Reference missing SYM ID.
19. Classify failed conflict proof as no conflict.
20. Modify trusted theorem body during binding.
