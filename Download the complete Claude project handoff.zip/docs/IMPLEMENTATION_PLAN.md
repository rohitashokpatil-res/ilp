# Implementation Plan

## Phase 1

- Schema registry and Draft 2020-12 validation
- Evidence validation
- Cross-reference validation
- Structured errors

## Phase 2

- Context canonicalization
- Stable ID allocation
- Carry-forward checks
- Audit records

## Phase 3

- Lean token validation
- Declaration metadata validation
- Dependency DAG
- Deterministic assembler
- Line/source manifest

## Phase 4

- Lean/Lake environment detection
- Preamble compilation
- Per-requirement compilation
- Complete-model compilation
- Diagnostic parsing and timeouts

## Phase 5

- Trusted template registry
- File hashing
- Exact typed binding validation
- Deterministic test assembly
- Per-test compilation
- Result classification

## Phase 6

- Unit tests
- Integration fixtures
- Mutation tests
- End-to-end acceptance suite
