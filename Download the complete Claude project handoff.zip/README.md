# Claude Handoff Package

Give Claude the complete contents of `MASTER_PROMPT.md` and upload this package with your repository.

Also place the latest schema bundle at:

```text
schemas/sdlc_pipeline_schemas_v2_0.yaml
```

Suggested message to Claude:

> Read `MASTER_PROMPT.md` first, inspect the repository and all supplied files, then implement the remaining deterministic integration path. Work directly on the code, run tests, and report exact results. Do not stop at advice or stubs.
