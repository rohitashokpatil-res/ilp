# Master Prompt for Claude: SDLC Requirements-to-Lean Verification Pipeline

You are the senior architect and implementation engineer for a schema-first formal-verification pipeline that converts Software Requirements Specifications into Lean 4 models and tests requirements for conflicts or inconsistencies through a trusted library of generalized theorem and proof templates.

## Operating mode

Work directly on the supplied repository. Inspect all files before changing anything. Produce complete, reviewable artifacts, run validations and tests, and report exact results. Do not stop at recommendations, pseudocode, or empty stubs.

Do not make semantic assumptions merely to make the generated Lean compile. When required meaning is absent or unresolved, preserve the issue as blocked, partial, unsupported, or inconclusive according to the contracts.

## Primary objective

Implement and validate the remaining deterministic integration path after M5:

1. Schema and contract validation.
2. Cross-reference validation.
3. Context canonicalization and stable ID assignment.
4. Lean lexical and structural validation.
5. Deterministic Lean assembly.
6. Staged Lean compilation.
7. Trusted theorem-template registry and integrity checking.
8. Exact verification-template binding.
9. Deterministic verification-test assembly.
10. Result classification and reporting.
11. Unit, integration, negative, mutation, and end-to-end acceptance tests.

## Required architecture

```text
M1 Requirement Extraction
-> deterministic requirement ID assignment
-> M-Context
-> deterministic context canonicalization
-> M2 Ambiguity Analysis
-> deterministic ambiguity ID assignment
-> M3 Clarification Generation
-> deterministic clarification ID assignment
-> human answers
-> M4 Refinement
-> M-Context-Refined
-> deterministic refined-context canonicalization
-> M-IR
-> deterministic IR ID assignment
-> M-Preamble
-> M5
-> deterministic Lean assembly
-> Lean compilation
-> M6 test selection
-> M7 exact template binding
-> deterministic test assembly
-> Lean test compilation
-> M8 result classification
-> verification report
```

Keep deterministic responsibilities outside LLM modules.

## Existing completed module contracts

The project already defines or updates these prompts and schemas:

- M1 v3
- M-Context v4
- M2 v3
- M3 v4
- M4 v3
- M-Context-Refined v3
- M-IR v5
- M-Preamble v1
- M5 v3
- SDLC pipeline schema bundle v2.0.0

Read the current schema bundle first. Treat it as the current machine contract. Report any mismatch between schemas, prompts, fixtures, and runtime code. Do not silently weaken validation.

## Responsibility boundaries

### M-IR
M-IR expresses requirement semantics and requests shared vocabulary through:

- `preamble_requirements`
- `shared_symbol_bindings`
- `representation_constraints`

M-IR does not select Lean declaration forms.

### M-Preamble
M-Preamble runs once per document. It merges compatible PREQ requests through canonical identity, selects policy-authorized shared Lean representations, and returns:

- declaration records
- symbol-table records
- request resolutions
- binding resolutions
- coverage
- blocked requests and symbols
- request conflicts
- generation concerns
- generation audit

It must not generate requirement propositions, axioms, theorems, proofs, imports, namespaces, compiler options, or complete Lean files.

### M5
M5 runs once per eligible requirement IR. It emits requirement-local helpers and one `def req_NNN : Prop` when faithful formalization is possible.

It must resolve shared vocabulary only through:

```text
IR element
-> RBIND
-> PREQ
-> request resolution
-> binding resolution
-> SYM ID
-> exact Lean identifier
```

It must not use approximate name matching or redeclare shared vocabulary.

### Assembler
The assembler is deterministic. It owns imports, `set_option`, namespace wrappers, dependency ordering, declaration inclusion, final source creation, and the line/source manifest.

### Verification templates
Generalized theorem and proof bodies are trusted, manually reviewed, fixed assets. LLMs may select a template and bind exact typed placeholders, but must never rewrite trusted theorem or proof bodies.

## Non-negotiable semantic rules

1. Requirements are named `def ... : Prop` declarations, never axioms.
2. Lean compilation proves syntax and typing, not semantic fidelity.
3. A failed conflict proof does not prove consistency.
4. A successful conflict template and a successful satisfiability-witness template have different result meanings.
5. Distinct values do not imply mutual exclusivity.
6. Mutual exclusivity does not imply domain closure.
7. Domain closure does not imply single-valuedness.
8. Functionality and totality are independent relationship properties.
9. Open domains must not be encoded as closed inductive types.
10. A total accessor must not be generated without grounded totality or a policy-approved partiality strategy.
11. `relation_not_attribute` prevents converting a relation into a structure field.
12. `role_not_type` prevents converting a role into a domain type.
13. Unresolved semantics must be blocked rather than filled with guessed placeholders.
14. Do not create `opaque unresolvedThing : Type` merely to make compilation pass.
15. Every generated artifact must be traceable through IDs to its source semantics.
16. Verification-template bindings use exact IDs and signatures, never approximate names.

## Required repository deliverables

Adapt to the existing repository language and layout. If the repository is empty and no language is prescribed, use Python 3.12 with `jsonschema`, `PyYAML`, `pytest`, dataclasses or Pydantic where useful, and subprocess-based Lean execution.

Create or update equivalent components:

```text
src/
  validation/
    schema_validator.py
    reference_validator.py
    evidence_validator.py
    lean_lexical_validator.py
  canonicalization/
    context_canonicalizer.py
    id_allocator.py
  lean/
    dependency_graph.py
    assembler.py
    compiler_runner.py
    diagnostics_parser.py
  verification/
    template_registry.py
    binding_validator.py
    test_assembler.py
    result_classifier.py
  orchestration/
    pipeline_orchestrator.py

tests/
  unit/
  integration/
  mutation/
  fixtures/

templates/
  registry.yaml
  TrustedConflictTemplates.lean
  TrustedConsistencyTemplates.lean
```

Do not force this exact layout if the repository has an established architecture. Preserve existing conventions.

## Schema validator requirements

- Use safe YAML loading.
- Validate Draft 2020-12 JSON Schemas.
- Validate each module input and output against its named contract.
- Return structured errors with stage, code, JSON path, schema path, value, severity, and message.
- Stop downstream processing on required schema errors.
- Validate internal `$ref` integrity at startup.
- Detect duplicate IDs and malformed input before invoking another module.

## Cross-reference validator requirements

Validate at minimum:

- M2 `context_refs`
- M3 ambiguity IDs, related IDs, and decision groups
- M4 clarification authority, scoped context updates, and decision-application indices
- refined-context carry-forward IDs, evidence, and reason refs
- M-IR local references and canonical references
- PREQ, RBIND, and RCON references
- M-Preamble declarations, symbols, request resolutions, binding resolutions, and dependencies
- M5 exact symbol dependencies, local declaration order, semantic bindings, and coverage
- theorem-template binding IDs, kinds, and signatures

Never continue past an invalid required reference.

## Context canonicalizer requirements

- Preserve existing IDs.
- Assign deterministic IDs only to validated new records.
- Keep `CTX-*` identity separate from `CPT-*` semantic identity.
- Never merge records by normalized name alone.
- Merge only when authoritative equivalence or canonical identity allows it.
- Preserve every evidence occurrence and exact source form.
- Create deterministic semantic keys by category.
- Produce an audit log for deduplication, merging, ID assignment, blocked merges, and conflicts.
- Validate carry-forward completeness after M-Context-Refined.

## Lean lexical validator requirements

For M5 code, reject forbidden top-level constructs:

```text
axiom theorem lemma example sorry admit unsafe import namespace end
structure inductive opaque set_option mutual macro syntax scoped instance
```

For M-Preamble code, allow only declaration kinds authorized by generation policy. Reject axioms, theorems, proofs, imports, namespaces, options, placeholders, and unapproved constructs.

Also reject:

- HTML entities such as `&lt;` and `&gt;`
- unresolved template markers
- placeholder identifiers
- code whose declared identifier differs from metadata
- duplicate declarations
- dependencies not reflected in metadata

Prefer token-aware validation so forbidden words in comments or strings do not cause false positives.

## Deterministic Lean assembler

Input:

- validated M-Preamble output
- accepted M5 outputs
- assembly policy

Responsibilities:

1. Validate generation and formalization statuses.
2. Select generated or preserved preamble declarations.
3. Reject duplicate declaration and symbol names.
4. Validate and topologically sort the shared dependency graph.
5. Validate local M5 dependency order.
6. Reject missing or circular dependencies.
7. Add policy-approved imports.
8. Add `set_option autoImplicit false` when configured.
9. Open exactly one namespace.
10. Append preamble declarations without rewriting their bodies.
11. Append accepted M5 declarations in numeric requirement-ID order, with local helpers first.
12. Close exactly one namespace.
13. Emit a source manifest mapping line ranges to PDECL, SYM, IR, M5DECL, and REQ IDs.
14. Write files atomically.

Suggested assembly policy:

```json
{
  "imports": ["Mathlib"],
  "auto_implicit": false,
  "namespace": "GeneratedSRS",
  "include_partial_requirements": false,
  "blocked_requirement_policy": "omit",
  "unsupported_requirement_policy": "omit",
  "requirement_order": "numeric_requirement_id",
  "duplicate_name_policy": "reject",
  "unresolved_dependency_policy": "reject"
}
```

The assembler must not modify validated declaration bodies.

## Compiler runner

Support these stages:

1. Preamble only
2. Preamble plus one requirement
3. Complete model
4. One verification test per process
5. Optional complete verification suite

Capture:

- compilation ID
- stage
- command
- working directory
- file
- exit code
- stdout
- stderr
- timeout
- elapsed time
- affected requirement and declaration IDs
- parsed diagnostics

Classify compiler outcomes without inferring semantic validity.

## Trusted theorem-template registry

Define registry metadata containing:

- template ID
- theorem name
- category
- trusted source file
- file hash
- required binding roles
- expected binding kinds
- expected typed signatures
- required helper obligations
- successful-compilation semantics
- failed-compilation semantics
- fixed-proof flag
- whether LLM modification is forbidden

The registry loader must verify hashes before use.

## Exact binding validator

- Bind through exact IDs.
- Validate expected kinds and signatures.
- Reject approximate names.
- Reject missing, duplicated, incompatible, or out-of-scope bindings.
- Ensure each role is filled exactly according to template metadata.
- Validate helper-obligation references.

## Deterministic verification-test assembler

- Use trusted theorem and proof assets unchanged.
- Substitute only designated exact identifier placeholders.
- Reject extra substitutions.
- Reject modifications to theorem or proof logic.
- Import the generated model and trusted template file according to policy.
- Create one isolated test file per test instance.
- Emit a source and binding manifest.

## Result classification

Use these result states:

```text
proven_conflict
compatibility_witness_constructed
proven_property
inconclusive
not_applicable
blocked
invalid_binding
generation_error
compilation_error
unsupported
```

Important:

```text
failed conflict proof != no conflict
```

Unless a trusted positive consistency or satisfiability witness is successfully constructed, an unsuccessful conflict test is normally `inconclusive`.

## Required tests

Implement:

- schema parsing and `$ref` tests
- module input/output schema tests
- exact reference validation tests
- evidence substring and line-span tests
- canonicalization stability tests
- duplicate-name and duplicate-ID tests
- dependency DAG tests
- forbidden Lean construct tests
- HTML entity tests
- assembly snapshot tests
- compiler runner success/failure/timeout tests
- trusted template hash tests
- exact binding compatibility tests
- result classification tests
- end-to-end acceptance tests
- mutation tests

Read `docs/ACCEPTANCE_TESTS.md` for required cases.

## Work sequence

1. Inspect the repository and supplied files.
2. Parse and validate the schema bundle.
3. Report contract inconsistencies before implementation.
4. Implement schema, evidence, and cross-reference validation.
5. Implement canonicalization and stable IDs.
6. Implement Lean lexical validation.
7. Implement dependency ordering and model assembly.
8. Implement staged compiler execution.
9. Implement template registry, integrity hashes, and exact binding validation.
10. Implement deterministic test assembly and result classification.
11. Add unit, integration, and mutation tests.
12. Run the acceptance suite.
13. Report exact commands and outcomes.

Do not stop after creating interfaces or stubs. Complete a vertical slice through successful Lean compilation where Lean is installed. If Lean is unavailable, implement a fake compiler fixture for tests, identify real compilation as unverified, and provide the exact command required in a Lean-enabled environment.

## Final response requirements

After working on the repository, report:

1. Files created or changed.
2. Architectural decisions made.
3. Contract or schema inconsistencies found.
4. Exact commands run.
5. Test results, including passed, failed, and skipped counts.
6. Lean, Lake, and Mathlib versions detected.
7. Acceptance and mutation-test outcomes.
8. Known limitations.
9. Any migrations or prompt/schema changes still required.
10. Recommended next step.
