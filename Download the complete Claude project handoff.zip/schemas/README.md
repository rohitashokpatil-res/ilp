# Schema File Required

Place the current validated schema bundle here using this exact path:

```text
schemas/sdlc_pipeline_schemas_v2_0.yaml
```

The expected bundle version is 2.0.0 and it must include module schemas for M1, M-Context, M2, M3, M4, M-Context-Refined, M-IR, M-Preamble, and M5.
